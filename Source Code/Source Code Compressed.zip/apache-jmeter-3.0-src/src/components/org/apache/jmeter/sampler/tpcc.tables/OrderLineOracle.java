package org.apache.jmeter.sampler.tpcc.tables;

import java.sql.Timestamp;
/**
 * Defines the fields of the OrderLine table when testing with Oracle database
 * @author naman
 *
 */

public class OrderLineOracle {
	

	public int ol_w_id;
	public int ol_d_id;
	public int ol_o_id;
	public int ol_number;
	public int ol_i_id;
	public int ol_supply_w_id;
	public int ol_quantity;
	public String ol_delivery_d;
	public float ol_amount;
	public String ol_dist_info;

	@Override
	public String toString() {
		return ("\n***************** OrderLine ********************"
				+ "\n*        ol_w_id = " + ol_w_id + "\n*        ol_d_id = "
				+ ol_d_id + "\n*        ol_o_id = " + ol_o_id
				+ "\n*      ol_number = " + ol_number + "\n*        ol_i_id = "
				+ ol_i_id + "\n*  ol_delivery_d = " + ol_delivery_d
				+ "\n*      ol_amount = " + ol_amount + "\n* ol_supply_w_id = "
				+ ol_supply_w_id + "\n*    ol_quantity = " + ol_quantity
				+ "\n*   ol_dist_info = " + ol_dist_info + "\n**********************************************");
	}

}
