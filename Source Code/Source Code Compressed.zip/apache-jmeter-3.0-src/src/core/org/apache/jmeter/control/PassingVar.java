package org.apache.jmeter.control;

public class PassingVar
{
	public static int numwhs=33;
	public static String dburl;
	public static String driver;
	public static String username;
	public static String password;
	public static String dbname;
	public static int status;
	
}